﻿using BattleshipCore.Model;
using System;
using System.Collections.Generic;
using System.Text;

namespace BattleshipCore.GameLogic
{
    public interface IPlayerInitializer
    {
        Player InitializePlayer();
        BattleBoard DeployShips(BattleBoard brd, List<Ship> ships);
    }
}
