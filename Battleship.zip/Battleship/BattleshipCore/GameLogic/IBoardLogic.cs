﻿using BattleshipCore.Model;
using System;
using System.Collections.Generic;
using System.Text;

namespace BattleshipCore.GameLogic
{
    public interface IBoardLogic
    {
        BattleBoard InitializeBattleBoard();

        BattleBoard DeployShips(BattleBoard brd, List<Ship> ships);
    }
}
