﻿using System;
using Microsoft.Extensions.DependencyInjection;
using BattleshipCore.GameLogic;
using System.Collections.Generic;
using BattleshipCore.Model;

namespace Battleship
{
    class Program
    {
        
        private static IServiceProvider _serviceProvider;
        private static int turnCounter;
        static void RegisterServices()
        {
            var svcCollection = new ServiceCollection();
            svcCollection.AddScoped<IPlayerInitializer, PlayerInitializer>();
            svcCollection.AddScoped<IBoardLogic, BoardLogic>();
            svcCollection.AddScoped<IGamePlayLogic, GamePlayLogic>();


            _serviceProvider = svcCollection.BuildServiceProvider();
        }

        static void DisposeServices()
        {
            if(_serviceProvider != null)
            {
                ((IDisposable)_serviceProvider).Dispose();
            }
        }
        static void Main(string[] args)
        {
            RegisterServices();
            Console.WriteLine("Battleship Game Play...");
            Console.ReadLine();
            var p1Initializer = _serviceProvider.GetService<IPlayerInitializer>();
            var p1 = p1Initializer.InitializePlayer();
            p1.Ships = GetShips();
            p1Initializer.DeployShips(p1.GameBoard, p1.Ships);           
            PrintBattleBoard<string>(p1.GameBoard.Board, 1);

            var p2Initializer = _serviceProvider.GetService<IPlayerInitializer>();
            var p2 = p1Initializer.InitializePlayer();
            p2.Ships = GetShips();
            p2Initializer.DeployShips(p2.GameBoard, p2.Ships);
            PrintBattleBoard<string>(p2.GameBoard.Board, 2);

            // Kind of a Toss between the two players, BTW Toss can be moved to the Game play Logic
            DecideFirstPlayer();

            //Initialize GamePlayLogic
            var gamePlay = _serviceProvider.GetService<IGamePlayLogic>();
            while (gamePlay.CheckOpponetIsAllDown(p1) == false && gamePlay.CheckOpponetIsAllDown(p2) == false)
            {
                Console.WriteLine($"Player {turnCounter.ToString()} please take your turn (Enter Target Coordinates YX [where Y and X are numbers between 0-9])");
                Console.WriteLine($"At any time, type exit and hit enter key, to exit the game ");

                string Coordinate = Console.ReadLine();
                if (Coordinate.ToUpper() == "EXIT")
                    Environment.Exit(0);

                Player Opponent;
                if (turnCounter == 1)
                {
                    // player 1 will take turn, Opponent will be player 2
                    Opponent = p2;
                }
                else
                {
                    Opponent = p1;
                }
                bool success = false;
                bool isSunk = false;
                string shipname = string.Empty;
                gamePlay.AttackOpponent(Opponent, Coordinate, out success, out isSunk, out shipname);
                if(!success)
                {
                    Console.WriteLine("Not on Target");
                }
                else if(success && !isSunk)
                {
                    Console.WriteLine("It is a hit!");
                }
                else if(success && isSunk)
                {
                    Console.WriteLine($"{shipname} is Down.. Hurray !!");
                }
                if (turnCounter == 1)
                {
                    turnCounter = 2;
                    continue;
                }
                if(turnCounter == 2)
                {
                    turnCounter = 1;
                    continue;
                }

            }
            bool isP1Down = gamePlay.CheckOpponetIsAllDown(p1);
            bool isP2Down = gamePlay.CheckOpponetIsAllDown(p2);
            if(isP1Down)
            {
                Console.WriteLine("Player 2 wins the game");
            }
            else if(isP2Down)
            {
                Console.WriteLine("Player 1 wins the game");
            }
            else
            {
                Console.WriteLine("Seems like a problem");
            }

            Console.ReadLine();
            DisposeServices();
        }

        public static void PrintBattleBoard<T>(T[,] battleBoard, int player)
        {
            Console.WriteLine("");
            Console.WriteLine("");
            Console.WriteLine("***********************************");
            Console.WriteLine($"Player {player} Battle Board");
            Console.WriteLine("***********************************");
            for (int i = 0; i < battleBoard.GetLength(0); i++)
            {
                for (int j = 0; j < battleBoard.GetLength(1); j++)
                {
                    Console.Write(battleBoard[i, j] + "\t");
                }
                Console.WriteLine();
            }
        }

        static List<Ship> GetShips()
        {
            // For the sake of this coding challenge i am going to assume both players would have the same ships.
            // we can extend this to get this ship data from User Input, but that will be over kill for this test.
            List<Ship> lsShips = new List<Ship>();
            // add Patrolling Ship
            lsShips.Add(new Ship() { Size = 2, State = "OK", Type = "Patrolling" });
            // add another Patrolling Ship
            lsShips.Add(new Ship() { Size = 2, State = "OK", Type = "Patrolling" });
            // add Destroyer Ship
            lsShips.Add(new Ship() { Size = 3, State = "OK", Type = "Destroyer" });
            // add Battleship Ship
            lsShips.Add(new Ship() { Size = 4, State = "OK", Type = "Battleship" });

            return lsShips;
        }

        static void  DecideFirstPlayer()
        {
            Random rn = new Random();
            int factor = rn.Next(0 , 9);
            turnCounter = factor % 2 == 0 ? 1 : 2;
        }
    }
}
