﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BattleshipCore.Model
{
    public class Cell 
    {
        public int XCord { get; set; }
        public int YCord { get; set; }
        public bool IsHit { get; set; }       
    }    
}
