﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BattleshipCore.Model
{
    public class Ship
    {
        public string Type { get; set; }
        public string State { get; set; }
        public int Size { get; set; }
        public List<Cell> ShipDeck { get; set; }
        public bool IsSunk
        {
            get
            {
                if (this.ShipDeck == null)
                    return false;

                if (this.ShipDeck.FindAll(f => f.IsHit).Count == this.ShipDeck.Count)
                {
                    return true;
                }
           
                return false;
            }
        }
    }
}
