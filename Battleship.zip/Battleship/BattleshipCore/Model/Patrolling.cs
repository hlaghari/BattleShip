﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BattleshipCore.Model
{
    public class Patrolling : Ship
    {
    }
}
