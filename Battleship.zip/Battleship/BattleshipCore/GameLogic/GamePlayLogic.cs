﻿using System;
using System.Collections.Generic;
using System.Text;
using BattleshipCore.Model;

namespace BattleshipCore.GameLogic
{
    public class GamePlayLogic : IGamePlayLogic
    {
        public void AttackOpponent(Player opponentPlayer, string attackCoordinates, out bool success, out bool isSunk, out string shipName)
        {
            success = false;
            isSunk = false;
            shipName = string.Empty;

            // in real scenario this will never happen but just to avoid any exceptions
            if (opponentPlayer == null || string.IsNullOrWhiteSpace(attackCoordinates))
                return;
            // in real scenario this will never happen but just to avoid any exceptions
            if (opponentPlayer.GameBoard == null)
                return;

            // just in case if we get a coordinate that is not x and y. Though we have a check in the game turn
            // we will not allow the user to enter the string that is not conforming to XY coordinate.
            int XCord = -1;
            int YCord = -1;
            if (!validateCoordinate(attackCoordinates, out XCord, out YCord))
                return;

            //Coordinates are valid now Find a ship that has a Deck at these Coordinates 
            if(opponentPlayer.Ships != null && opponentPlayer.Ships.Count>0)
            {
                //Ship shTarget = opponentPlayer.Ships.Find(f => f.ShipDeck.Find(sd => sd.XCord == XCord && sd.YCord == YCord) != null);
                foreach(Ship sh in opponentPlayer.Ships)
                {
                    // you can't hit the ship that is already sunk.
                    if (sh.IsSunk)
                        continue;
                    // you can't hit the previously hit cell.
                    Cell cDeckCord = sh.ShipDeck.Find(f => f.XCord == XCord && f.YCord == YCord && f.IsHit == false);
                    if(cDeckCord != null)
                    {
                        // it is a hit
                        cDeckCord.IsHit = true;
                        success = true;
                        isSunk = sh.IsSunk;
                        shipName = sh.Type;
                        break;
                    }
                }
            }
        }

        public bool CheckOpponetIsAllDown(Player opponentPlayer)
        {
            bool ifAllShipsSunk = true;
            if(opponentPlayer != null)
            {
                if(opponentPlayer.Ships != null)
                {
                    foreach (Ship sh in opponentPlayer.Ships)
                    {
                        if (!sh.IsSunk)
                        {
                            ifAllShipsSunk = false;
                        }
                    }
                }
            }
            return ifAllShipsSunk;
        }

        private bool validateCoordinate(string attackCoordinates, out int iXCord, out int iYCord)
        {
            iXCord = -1;
            iYCord = -1;
            if (attackCoordinates.Trim().Length != 2)
            {
                return false;
            }
            char XCord = (attackCoordinates.Trim().ToCharArray())[0];
            char YCord = (attackCoordinates.Trim().ToCharArray())[1];
           
            bool isXInt = int.TryParse(XCord.ToString(), out iXCord);
            bool isYInt = int.TryParse(YCord.ToString(), out iYCord);
            if (!isXInt || !isYInt)
                return false;

            if (iXCord < 0 && iXCord > 9)
                return false;

            if (iYCord < 0 && iYCord > 9)
                return false;

            return true;

        }
    }
}
