﻿using System;
using System.Collections.Generic;
using System.Text;
using BattleshipCore.Model;

namespace BattleshipCore.GameLogic
{
    public class BoardLogic : IBoardLogic
    {
        public BattleBoard InitializeBattleBoard()
        {
            BattleBoard brd = new BattleBoard();
            brd.Board = new string[10, 10];
            this.setBoardToOcean(brd);
            return brd;
        }

        private void setBoardToOcean(BattleBoard brd)
        {
            for (int i = 0; i < 10; i++)
            {
                for (int j = 0; j < 10; j++)
                {
                    brd.Board[i, j] = "_";
                }
            }
        }

        public BattleBoard DeployShips(BattleBoard brd, List<Ship> ships)
        {
            if (brd == null)
                brd = this.InitializeBattleBoard();

            if (ships == null || ships.Count <= 0)
                return brd;
            foreach(Ship sh in ships)
            {
                DeployShip(brd, sh);
            }

            return brd;
        }

        private void DeployShip(BattleBoard brd, Ship sh)
        {
            bool deployed = false;

            while (!deployed)
            {
                sh.ShipDeck = new List<Cell>();
                Random rn = new Random();

                int horVert = rn.Next(0, 5) + 1;
                bool isHorizontal = horVert % 2 == 0 ? true : false;
                int randomX = rn.Next(0, 9);
                int randomY = rn.Next(0, 9);
                bool ifIncX = false;
                bool ifIncY = false;
                if (isHorizontal)
                {
                    if (randomX + sh.Size > 9)
                    {
                        //this means if we plot ship from left to right it will go out of the board so we better try decrement
                        //we do nothing here and leave ifInX as is and plot ship right to left
                    }
                    else
                    {
                        // means we can plot left to right
                        ifIncX = true;

                    }
                }
                else
                {
                    if (randomY + sh.Size > 9)
                    {
                        //this means if we plot ship from top to bottom it will go out of the board so we better try decrement
                        //we do nothing here and leave ifIncY as is and plot ship bottom up
                    }
                    else
                    {
                        // means we can plot top to bottom
                        ifIncY = true;
                    }
                }

                //Check if we have space available and we can deploy ship
                int startX = randomX;
                int startY = randomY;
                bool isFree = true;
                if (isHorizontal)
                {
                    for (int sizeIndex = 1; sizeIndex <= sh.Size; sizeIndex++)
                    {
                        if (brd.Board[startX, startY] == "_")
                        {
                            startX = ifIncX ? (startX+1) : (startX-1);
                        }
                        else
                        {
                            isFree = false;
                        }
                        if (!isFree)
                            break;
                    }
                    if (brd.Board[startX, startY] != "_")
                        isFree = false;

                    if (isFree)
                    {
                        //Space is available, plot
                        startX = randomX;
                        for (int sizeIndex = 1; sizeIndex <= sh.Size; sizeIndex++)
                        {
                            brd.Board[startX, startY] = "S"; // Set the board with Ship symbol S
                            sh.ShipDeck.Add(new Cell()
                                {
                                    IsHit = false,
                                    XCord = startX,
                                    YCord = startY
                                });
                            startX = ifIncX ? (startX + 1) : (startX - 1);
                        }
                        deployed = true;
                    }

                }
                else
                {
                    for (int sizeIndex = 1; sizeIndex <= sh.Size; sizeIndex++)
                    {
                        if (brd.Board[startX, startY] == "_")
                        {
                            startY = ifIncY ? (startY+1) : (startY-1);
                        }
                        else
                        {
                            isFree = false;
                        }
                        if (!isFree)
                            break;
                    }
                    if (brd.Board[startX, startY] != "_")
                        isFree = false;

                    if (isFree)
                    {
                        //Space is available plot
                        startY = randomY;
                        for (int sizeIndex = 1; sizeIndex <= sh.Size; sizeIndex++)
                        {
                            brd.Board[startX, startY] = "S"; // Set the board with Ship symbol S
                            sh.ShipDeck.Add(new Cell()
                            {
                                IsHit = false,
                                XCord = startX,
                                YCord = startY
                            });
                            startY = ifIncY ? (startY+1) : (startY-1);
                        }
                        deployed = true;
                    }
                }
            }
        }
    }
}
