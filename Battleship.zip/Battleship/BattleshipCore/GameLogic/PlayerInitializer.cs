﻿using System;
using System.Collections.Generic;
using System.Text;
using BattleshipCore.Model;

namespace BattleshipCore.GameLogic
{
   
    public class PlayerInitializer : IPlayerInitializer
    {
        IBoardLogic _boardInitializer;
        public PlayerInitializer(IBoardLogic bi)
        {
            this._boardInitializer = bi;
        }

        public Player InitializePlayer()
        {
            Player _player = new Player();
            _player.GameBoard = this._boardInitializer.InitializeBattleBoard();
            return _player;
        }

        public BattleBoard DeployShips(BattleBoard brd, List<Ship> ships)
        {
            if(ships == null || ships.Count == 0)
            {
                return brd;
            }
            return this._boardInitializer.DeployShips(brd, ships);            
        }

    }
}
