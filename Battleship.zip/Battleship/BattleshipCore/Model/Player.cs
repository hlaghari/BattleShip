﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BattleshipCore.Model
{
    public class Player
    {
        public BattleBoard GameBoard { get; set; }
        public TrackBoard Tracker { get; set; }
        public List<Ship> Ships { get; set; }
        public int turns { get; set; }
    }
}
