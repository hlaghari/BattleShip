﻿using BattleshipCore.Model;
using System;
using System.Collections.Generic;
using System.Text;

namespace BattleshipCore.GameLogic
{
    public interface IGamePlayLogic
    {
        void AttackOpponent(Player opponentPlayer, string attackCoordinates, out bool success, out bool isSunk, out string shipName);

        bool CheckOpponetIsAllDown(Player opponentPlayer);
    }
}
